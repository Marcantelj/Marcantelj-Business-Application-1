﻿namespace Marcantel_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.titleLabel = new System.Windows.Forms.Label();
            this.guestinformationGroupBox = new System.Windows.Forms.GroupBox();
            this.lastnameLabel = new System.Windows.Forms.Label();
            this.firstnameLabel = new System.Windows.Forms.Label();
            this.lastnameTextBox = new System.Windows.Forms.TextBox();
            this.firstnameTextBox = new System.Windows.Forms.TextBox();
            this.roominformationGroupBox = new System.Windows.Forms.GroupBox();
            this.nightlydollarrateLabel = new System.Windows.Forms.Label();
            this.nightsstayedLabel = new System.Windows.Forms.Label();
            this.guestsroomnumberLabel = new System.Windows.Forms.Label();
            this.nightlydollarrateTextBox = new System.Windows.Forms.TextBox();
            this.nightsstayedTextBox = new System.Windows.Forms.TextBox();
            this.guestsroomnumberTextBox = new System.Windows.Forms.TextBox();
            this.additionalchargesGroupBox = new System.Windows.Forms.GroupBox();
            this.miscellaneouschargesTextBox = new System.Windows.Forms.TextBox();
            this.telephonechargesTextBox = new System.Windows.Forms.TextBox();
            this.minibarchargesTextBox = new System.Windows.Forms.TextBox();
            this.miscellaneouschargesLabel = new System.Windows.Forms.Label();
            this.telephonechargesLabel = new System.Windows.Forms.Label();
            this.minibarchargesLabel = new System.Windows.Forms.Label();
            this.billingsummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.groupBoxline = new System.Windows.Forms.GroupBox();
            this.TotalLabel = new System.Windows.Forms.Label();
            this.taxsLabel = new System.Windows.Forms.Label();
            this.sublabel = new System.Windows.Forms.Label();
            this.AddLabel = new System.Windows.Forms.Label();
            this.roomLabel = new System.Windows.Forms.Label();
            this.roomChargesLabel = new System.Windows.Forms.Label();
            this.additionalChargelabel = new System.Windows.Forms.Label();
            this.subtotalLabel = new System.Windows.Forms.Label();
            this.taxamountLabel = new System.Windows.Forms.Label();
            this.totalChargesLabel = new System.Windows.Forms.Label();
            this.totalButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.helpButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.dateMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.dateLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.guestinformationGroupBox.SuspendLayout();
            this.roominformationGroupBox.SuspendLayout();
            this.additionalchargesGroupBox.SuspendLayout();
            this.billingsummaryGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.BackColor = System.Drawing.Color.White;
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(298, 102);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(230, 34);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Motorway Motel";
            // 
            // guestinformationGroupBox
            // 
            this.guestinformationGroupBox.Controls.Add(this.lastnameLabel);
            this.guestinformationGroupBox.Controls.Add(this.firstnameLabel);
            this.guestinformationGroupBox.Controls.Add(this.lastnameTextBox);
            this.guestinformationGroupBox.Controls.Add(this.firstnameTextBox);
            this.guestinformationGroupBox.Location = new System.Drawing.Point(1, 177);
            this.guestinformationGroupBox.Name = "guestinformationGroupBox";
            this.guestinformationGroupBox.Size = new System.Drawing.Size(197, 263);
            this.guestinformationGroupBox.TabIndex = 3;
            this.guestinformationGroupBox.TabStop = false;
            this.guestinformationGroupBox.Text = "Guest Information";
            // 
            // lastnameLabel
            // 
            this.lastnameLabel.AutoSize = true;
            this.lastnameLabel.Location = new System.Drawing.Point(55, 104);
            this.lastnameLabel.Name = "lastnameLabel";
            this.lastnameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastnameLabel.TabIndex = 2;
            this.lastnameLabel.Text = "Last Name:";
            // 
            // firstnameLabel
            // 
            this.firstnameLabel.AutoSize = true;
            this.firstnameLabel.Location = new System.Drawing.Point(55, 30);
            this.firstnameLabel.Name = "firstnameLabel";
            this.firstnameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstnameLabel.TabIndex = 0;
            this.firstnameLabel.Text = "First Name:";
            // 
            // lastnameTextBox
            // 
            this.lastnameTextBox.Location = new System.Drawing.Point(39, 130);
            this.lastnameTextBox.Name = "lastnameTextBox";
            this.lastnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastnameTextBox.TabIndex = 3;
            // 
            // firstnameTextBox
            // 
            this.firstnameTextBox.Location = new System.Drawing.Point(39, 56);
            this.firstnameTextBox.Name = "firstnameTextBox";
            this.firstnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstnameTextBox.TabIndex = 1;
            // 
            // roominformationGroupBox
            // 
            this.roominformationGroupBox.Controls.Add(this.nightlydollarrateLabel);
            this.roominformationGroupBox.Controls.Add(this.nightsstayedLabel);
            this.roominformationGroupBox.Controls.Add(this.guestsroomnumberLabel);
            this.roominformationGroupBox.Controls.Add(this.nightlydollarrateTextBox);
            this.roominformationGroupBox.Controls.Add(this.nightsstayedTextBox);
            this.roominformationGroupBox.Controls.Add(this.guestsroomnumberTextBox);
            this.roominformationGroupBox.Location = new System.Drawing.Point(204, 177);
            this.roominformationGroupBox.Name = "roominformationGroupBox";
            this.roominformationGroupBox.Size = new System.Drawing.Size(208, 263);
            this.roominformationGroupBox.TabIndex = 4;
            this.roominformationGroupBox.TabStop = false;
            this.roominformationGroupBox.Text = "Room Information";
            // 
            // nightlydollarrateLabel
            // 
            this.nightlydollarrateLabel.AutoSize = true;
            this.nightlydollarrateLabel.Location = new System.Drawing.Point(51, 178);
            this.nightlydollarrateLabel.Name = "nightlydollarrateLabel";
            this.nightlydollarrateLabel.Size = new System.Drawing.Size(98, 13);
            this.nightlydollarrateLabel.TabIndex = 4;
            this.nightlydollarrateLabel.Text = "Nightly Dollar Rate:";
            // 
            // nightsstayedLabel
            // 
            this.nightsstayedLabel.AutoSize = true;
            this.nightsstayedLabel.Location = new System.Drawing.Point(62, 104);
            this.nightsstayedLabel.Name = "nightsstayedLabel";
            this.nightsstayedLabel.Size = new System.Drawing.Size(78, 13);
            this.nightsstayedLabel.TabIndex = 2;
            this.nightsstayedLabel.Text = "Night\'s Stayed:";
            // 
            // guestsroomnumberLabel
            // 
            this.guestsroomnumberLabel.AutoSize = true;
            this.guestsroomnumberLabel.Location = new System.Drawing.Point(43, 30);
            this.guestsroomnumberLabel.Name = "guestsroomnumberLabel";
            this.guestsroomnumberLabel.Size = new System.Drawing.Size(116, 13);
            this.guestsroomnumberLabel.TabIndex = 0;
            this.guestsroomnumberLabel.Text = "Guest\'s Room Number:";
            // 
            // nightlydollarrateTextBox
            // 
            this.nightlydollarrateTextBox.Location = new System.Drawing.Point(49, 203);
            this.nightlydollarrateTextBox.Name = "nightlydollarrateTextBox";
            this.nightlydollarrateTextBox.Size = new System.Drawing.Size(100, 20);
            this.nightlydollarrateTextBox.TabIndex = 5;
            this.nightlydollarrateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nightsstayedTextBox
            // 
            this.nightsstayedTextBox.Location = new System.Drawing.Point(49, 129);
            this.nightsstayedTextBox.Name = "nightsstayedTextBox";
            this.nightsstayedTextBox.Size = new System.Drawing.Size(100, 20);
            this.nightsstayedTextBox.TabIndex = 3;
            this.nightsstayedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // guestsroomnumberTextBox
            // 
            this.guestsroomnumberTextBox.Location = new System.Drawing.Point(49, 56);
            this.guestsroomnumberTextBox.Name = "guestsroomnumberTextBox";
            this.guestsroomnumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.guestsroomnumberTextBox.TabIndex = 1;
            this.guestsroomnumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // additionalchargesGroupBox
            // 
            this.additionalchargesGroupBox.Controls.Add(this.miscellaneouschargesTextBox);
            this.additionalchargesGroupBox.Controls.Add(this.telephonechargesTextBox);
            this.additionalchargesGroupBox.Controls.Add(this.minibarchargesTextBox);
            this.additionalchargesGroupBox.Controls.Add(this.miscellaneouschargesLabel);
            this.additionalchargesGroupBox.Controls.Add(this.telephonechargesLabel);
            this.additionalchargesGroupBox.Controls.Add(this.minibarchargesLabel);
            this.additionalchargesGroupBox.Location = new System.Drawing.Point(418, 177);
            this.additionalchargesGroupBox.Name = "additionalchargesGroupBox";
            this.additionalchargesGroupBox.Size = new System.Drawing.Size(194, 263);
            this.additionalchargesGroupBox.TabIndex = 5;
            this.additionalchargesGroupBox.TabStop = false;
            this.additionalchargesGroupBox.Text = "Additional Charges";
            // 
            // miscellaneouschargesTextBox
            // 
            this.miscellaneouschargesTextBox.Location = new System.Drawing.Point(46, 203);
            this.miscellaneouschargesTextBox.Name = "miscellaneouschargesTextBox";
            this.miscellaneouschargesTextBox.Size = new System.Drawing.Size(100, 20);
            this.miscellaneouschargesTextBox.TabIndex = 5;
            this.miscellaneouschargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // telephonechargesTextBox
            // 
            this.telephonechargesTextBox.Location = new System.Drawing.Point(46, 130);
            this.telephonechargesTextBox.Name = "telephonechargesTextBox";
            this.telephonechargesTextBox.Size = new System.Drawing.Size(100, 20);
            this.telephonechargesTextBox.TabIndex = 3;
            this.telephonechargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // minibarchargesTextBox
            // 
            this.minibarchargesTextBox.Location = new System.Drawing.Point(46, 55);
            this.minibarchargesTextBox.Name = "minibarchargesTextBox";
            this.minibarchargesTextBox.Size = new System.Drawing.Size(100, 20);
            this.minibarchargesTextBox.TabIndex = 1;
            this.minibarchargesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // miscellaneouschargesLabel
            // 
            this.miscellaneouschargesLabel.AutoSize = true;
            this.miscellaneouschargesLabel.Location = new System.Drawing.Point(43, 178);
            this.miscellaneouschargesLabel.Name = "miscellaneouschargesLabel";
            this.miscellaneouschargesLabel.Size = new System.Drawing.Size(119, 13);
            this.miscellaneouschargesLabel.TabIndex = 4;
            this.miscellaneouschargesLabel.Text = "Miscellaneous Charges:";
            // 
            // telephonechargesLabel
            // 
            this.telephonechargesLabel.AutoSize = true;
            this.telephonechargesLabel.Location = new System.Drawing.Point(43, 104);
            this.telephonechargesLabel.Name = "telephonechargesLabel";
            this.telephonechargesLabel.Size = new System.Drawing.Size(103, 13);
            this.telephonechargesLabel.TabIndex = 2;
            this.telephonechargesLabel.Text = "Telephone Charges:";
            // 
            // minibarchargesLabel
            // 
            this.minibarchargesLabel.AutoSize = true;
            this.minibarchargesLabel.Location = new System.Drawing.Point(56, 30);
            this.minibarchargesLabel.Name = "minibarchargesLabel";
            this.minibarchargesLabel.Size = new System.Drawing.Size(90, 13);
            this.minibarchargesLabel.TabIndex = 0;
            this.minibarchargesLabel.Text = "Mini Bar Charges:";
            // 
            // billingsummaryGroupBox
            // 
            this.billingsummaryGroupBox.Controls.Add(this.groupBoxline);
            this.billingsummaryGroupBox.Controls.Add(this.TotalLabel);
            this.billingsummaryGroupBox.Controls.Add(this.taxsLabel);
            this.billingsummaryGroupBox.Controls.Add(this.sublabel);
            this.billingsummaryGroupBox.Controls.Add(this.AddLabel);
            this.billingsummaryGroupBox.Controls.Add(this.roomLabel);
            this.billingsummaryGroupBox.Controls.Add(this.roomChargesLabel);
            this.billingsummaryGroupBox.Controls.Add(this.additionalChargelabel);
            this.billingsummaryGroupBox.Controls.Add(this.subtotalLabel);
            this.billingsummaryGroupBox.Controls.Add(this.taxamountLabel);
            this.billingsummaryGroupBox.Controls.Add(this.totalChargesLabel);
            this.billingsummaryGroupBox.Location = new System.Drawing.Point(618, 177);
            this.billingsummaryGroupBox.Name = "billingsummaryGroupBox";
            this.billingsummaryGroupBox.Size = new System.Drawing.Size(208, 263);
            this.billingsummaryGroupBox.TabIndex = 6;
            this.billingsummaryGroupBox.TabStop = false;
            this.billingsummaryGroupBox.Text = "Billing Summary";
            // 
            // groupBoxline
            // 
            this.groupBoxline.Location = new System.Drawing.Point(9, 203);
            this.groupBoxline.Name = "groupBoxline";
            this.groupBoxline.Size = new System.Drawing.Size(194, 10);
            this.groupBoxline.TabIndex = 8;
            this.groupBoxline.TabStop = false;
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Location = new System.Drawing.Point(26, 232);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(76, 13);
            this.TotalLabel.TabIndex = 9;
            this.TotalLabel.Text = "Total Charges:";
            // 
            // taxsLabel
            // 
            this.taxsLabel.AutoSize = true;
            this.taxsLabel.Location = new System.Drawing.Point(35, 163);
            this.taxsLabel.Name = "taxsLabel";
            this.taxsLabel.Size = new System.Drawing.Size(67, 13);
            this.taxsLabel.TabIndex = 6;
            this.taxsLabel.Text = "Tax Amount:";
            // 
            // sublabel
            // 
            this.sublabel.AutoSize = true;
            this.sublabel.Location = new System.Drawing.Point(53, 120);
            this.sublabel.Name = "sublabel";
            this.sublabel.Size = new System.Drawing.Size(49, 13);
            this.sublabel.TabIndex = 4;
            this.sublabel.Text = "Subtotal:";
            // 
            // AddLabel
            // 
            this.AddLabel.AutoSize = true;
            this.AddLabel.Location = new System.Drawing.Point(6, 80);
            this.AddLabel.Name = "AddLabel";
            this.AddLabel.Size = new System.Drawing.Size(98, 13);
            this.AddLabel.TabIndex = 2;
            this.AddLabel.Text = "Additional Charges:";
            // 
            // roomLabel
            // 
            this.roomLabel.AutoSize = true;
            this.roomLabel.Location = new System.Drawing.Point(22, 36);
            this.roomLabel.Name = "roomLabel";
            this.roomLabel.Size = new System.Drawing.Size(80, 13);
            this.roomLabel.TabIndex = 0;
            this.roomLabel.Text = "Room Charges:";
            // 
            // roomChargesLabel
            // 
            this.roomChargesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.roomChargesLabel.Location = new System.Drawing.Point(107, 30);
            this.roomChargesLabel.Name = "roomChargesLabel";
            this.roomChargesLabel.Size = new System.Drawing.Size(95, 24);
            this.roomChargesLabel.TabIndex = 1;
            this.roomChargesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // additionalChargelabel
            // 
            this.additionalChargelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.additionalChargelabel.Location = new System.Drawing.Point(107, 74);
            this.additionalChargelabel.Name = "additionalChargelabel";
            this.additionalChargelabel.Size = new System.Drawing.Size(95, 25);
            this.additionalChargelabel.TabIndex = 3;
            this.additionalChargelabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // subtotalLabel
            // 
            this.subtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.subtotalLabel.Location = new System.Drawing.Point(107, 114);
            this.subtotalLabel.Name = "subtotalLabel";
            this.subtotalLabel.Size = new System.Drawing.Size(95, 25);
            this.subtotalLabel.TabIndex = 5;
            this.subtotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxamountLabel
            // 
            this.taxamountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxamountLabel.Location = new System.Drawing.Point(107, 157);
            this.taxamountLabel.Name = "taxamountLabel";
            this.taxamountLabel.Size = new System.Drawing.Size(95, 25);
            this.taxamountLabel.TabIndex = 7;
            this.taxamountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalChargesLabel
            // 
            this.totalChargesLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalChargesLabel.Location = new System.Drawing.Point(107, 226);
            this.totalChargesLabel.Name = "totalChargesLabel";
            this.totalChargesLabel.Size = new System.Drawing.Size(95, 25);
            this.totalChargesLabel.TabIndex = 10;
            this.totalChargesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(58, 469);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(75, 23);
            this.totalButton.TabIndex = 7;
            this.totalButton.Text = "&Total";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(269, 469);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clea&r";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // helpButton
            // 
            this.helpButton.Location = new System.Drawing.Point(477, 469);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(75, 23);
            this.helpButton.TabIndex = 9;
            this.helpButton.Text = "H&elp";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(689, 469);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // dateMaskedTextBox
            // 
            this.dateMaskedTextBox.Location = new System.Drawing.Point(382, 143);
            this.dateMaskedTextBox.Mask = "00/00/0000";
            this.dateMaskedTextBox.Name = "dateMaskedTextBox";
            this.dateMaskedTextBox.Size = new System.Drawing.Size(67, 20);
            this.dateMaskedTextBox.TabIndex = 2;
            this.dateMaskedTextBox.ValidatingType = typeof(System.DateTime);
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Location = new System.Drawing.Point(343, 150);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(33, 13);
            this.dateLabel.TabIndex = 1;
            this.dateLabel.Text = "Date:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(228, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(352, 98);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 520);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.dateMaskedTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.helpButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.billingsummaryGroupBox);
            this.Controls.Add(this.additionalchargesGroupBox);
            this.Controls.Add(this.roominformationGroupBox);
            this.Controls.Add(this.guestinformationGroupBox);
            this.Controls.Add(this.titleLabel);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.guestinformationGroupBox.ResumeLayout(false);
            this.guestinformationGroupBox.PerformLayout();
            this.roominformationGroupBox.ResumeLayout(false);
            this.roominformationGroupBox.PerformLayout();
            this.additionalchargesGroupBox.ResumeLayout(false);
            this.additionalchargesGroupBox.PerformLayout();
            this.billingsummaryGroupBox.ResumeLayout(false);
            this.billingsummaryGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.GroupBox guestinformationGroupBox;
        private System.Windows.Forms.GroupBox roominformationGroupBox;
        private System.Windows.Forms.GroupBox additionalchargesGroupBox;
        private System.Windows.Forms.GroupBox billingsummaryGroupBox;
        private System.Windows.Forms.Label lastnameLabel;
        private System.Windows.Forms.Label firstnameLabel;
        private System.Windows.Forms.TextBox lastnameTextBox;
        private System.Windows.Forms.TextBox firstnameTextBox;
        private System.Windows.Forms.TextBox guestsroomnumberTextBox;
        private System.Windows.Forms.TextBox nightlydollarrateTextBox;
        private System.Windows.Forms.TextBox nightsstayedTextBox;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label nightlydollarrateLabel;
        private System.Windows.Forms.Label nightsstayedLabel;
        private System.Windows.Forms.Label guestsroomnumberLabel;
        private System.Windows.Forms.Label minibarchargesLabel;
        private System.Windows.Forms.TextBox miscellaneouschargesTextBox;
        private System.Windows.Forms.TextBox telephonechargesTextBox;
        private System.Windows.Forms.TextBox minibarchargesTextBox;
        private System.Windows.Forms.Label miscellaneouschargesLabel;
        private System.Windows.Forms.Label telephonechargesLabel;
        private System.Windows.Forms.Label roomChargesLabel;
        private System.Windows.Forms.Label additionalChargelabel;
        private System.Windows.Forms.Label subtotalLabel;
        private System.Windows.Forms.Label taxamountLabel;
        private System.Windows.Forms.Label totalChargesLabel;
        private System.Windows.Forms.Label sublabel;
        private System.Windows.Forms.Label AddLabel;
        private System.Windows.Forms.Label roomLabel;
        private System.Windows.Forms.Label taxsLabel;
        private System.Windows.Forms.MaskedTextBox dateMaskedTextBox;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label TotalLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBoxline;
    }
}

