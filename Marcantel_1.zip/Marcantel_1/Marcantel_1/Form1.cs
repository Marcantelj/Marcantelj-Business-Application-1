﻿// Programmer: Jonathan Marcantel
// Project: Marcantel_1
// Date: 09/11/2018
// Discription: Individual Assignment #1
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marcantel_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Declaring Local Constants 
                const decimal TAX_RATE = 0.07m;

                // Declaring Local Variables     
                double nights; // Number of nights stayed.
                decimal rate;  // Cost of the nightly rate.
                decimal minibar; // Charges incurred from the mini bar. 
                decimal telephone; // Charges incurred from the telephone.
                decimal misc;  // Miscellaneous charges incurred. 
                decimal roomCharge; // Room charges from the bill. 
                decimal addtlCharge; // Addtional charges from the bill. 
                decimal subtotal; // Subtotal of charges. 
                decimal tax; // Tax on subtotal of charges.
                decimal totalCharge; // Total charge for the guests stay. 

                // Get Values From Textboxes
                nights = double.Parse(nightsstayedTextBox.Text);
                rate = decimal.Parse(nightlydollarrateTextBox.Text);
                minibar = decimal.Parse(minibarchargesTextBox.Text);
                telephone = decimal.Parse(telephonechargesTextBox.Text);
                misc = decimal.Parse(miscellaneouschargesTextBox.Text);

                //Calculate room Charges
                roomCharge = (decimal)nights * rate;
                roomChargesLabel.Text = roomCharge.ToString("c");

                addtlCharge = (decimal)minibar + telephone + misc;
                additionalChargelabel.Text = addtlCharge.ToString("c");

                subtotal = (decimal)roomCharge + addtlCharge;
                subtotalLabel.Text = subtotal.ToString("c");

                tax = (decimal)subtotal * TAX_RATE;
                taxamountLabel.Text = tax.ToString("c");



                totalCharge = (decimal)tax + subtotal;
                totalChargesLabel.Text = totalCharge.ToString("c");
            }

            // Displaying the defualt error message.
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            // Set focus to clear button after totaled. 
            clearButton.Focus();
        }
        // Clearing all Outputs and Inputs
        private void clearButton_Click(object sender, EventArgs e)
        {
            firstnameTextBox.Text = "";
            lastnameTextBox.Text = "";
            guestsroomnumberTextBox.Text = "";
            nightsstayedTextBox.Text = "";
            dateMaskedTextBox.Text = "";
            nightlydollarrateTextBox.Text = "";
            minibarchargesTextBox.Text = "";
            telephonechargesTextBox.Text = "";
            miscellaneouschargesTextBox.Text = "";
            roomChargesLabel.Text = "";
            additionalChargelabel.Text = "";
            subtotalLabel.Text = "";
            taxamountLabel.Text = "";
            totalChargesLabel.Text = "";
        }
        
        // Exit Button that closes window. 
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        // Displays Help Button message.
        private void helpButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show
               ("First enter the date of when you are moving out. Then enter in Guests information, which will your First and Last Name. " +
               "Then enter in Room Information, guest's room number which is three digits long, nights you're staying, and nightly dollar rate. " +
               "Now enter in your Additional Charges for your room, Minibar Charge, Telephone Charges, and Miscellaneous Charges " +
               "Finally we can hit the \"Total Button\", this allows us to see what your totals are in the Billing Summary.");
        }
    }
}

 


